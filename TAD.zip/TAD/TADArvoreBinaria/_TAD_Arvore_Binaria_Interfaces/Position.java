package _TAD_Arvore_Binaria_Interfaces;

public interface Position<TIPO> {
	
	TIPO element();
}
