package g02.Ex_22_TAD_Hash_Table_Map.Excecoes;

@SuppressWarnings("serial")
public class ExcecaoArvoreVazia extends RuntimeException{
	
	public ExcecaoArvoreVazia(String mensagemErro) {
		
		super(mensagemErro);
	}
}
