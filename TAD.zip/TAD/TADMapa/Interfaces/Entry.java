package g02.Ex_22_TAD_Hash_Table_Map.Interfaces;

public interface Entry<KEY, VALUE> {
	
	public KEY getKey();
	
	public VALUE getValue();
}
