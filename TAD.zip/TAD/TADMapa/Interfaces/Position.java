package g02.Ex_22_TAD_Hash_Table_Map.Interfaces;

public interface Position<TIPO> {
	
	TIPO element();
}
