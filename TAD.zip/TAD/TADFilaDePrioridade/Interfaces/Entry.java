package g02.Ex_01_A_TAD_Fila_Prioridade.Interfaces;

public interface Entry<KEY, VALUE> {
	
	public KEY getKey();
	
	public VALUE getValue();
}
