package g02.Ex_01_A_TAD_Fila_Prioridade.Interfaces;

public interface Position<TIPO> {
	
	TIPO element();
}
