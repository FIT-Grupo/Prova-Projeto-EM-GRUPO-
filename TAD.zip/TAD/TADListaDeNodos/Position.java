package Ex_11_12_13_Lista_Nodos;

public interface Position<TIPO> {
	
	TIPO elemento();

}
