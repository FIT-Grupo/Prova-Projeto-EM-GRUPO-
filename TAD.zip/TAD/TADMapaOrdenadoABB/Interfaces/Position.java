package g02.Ex_02_TAD_Mapa_Ordenado_ABB.Interfaces;

//Interface para o posicionamento de objetos dentro de uma LISTA DE NODOS.
public interface Position<TYPE> {
	
	//Retorna o elemento armazenado na posi��o.
	TYPE element();
	
}