package _TAD_Arvore_Generica_Interfaces;

public interface Position<TIPO> {
	
	TIPO element();
}
